//
//  SwitchCell.swift
//  Yelp
//
//  Created by NicoleA on 4/6/17.
//  Copyright © 2017 Timothy Lee. All rights reserved.
//

import UIKit

//naming convention for interface
@objc protocol SwitchCellDelegate {
    @objc optional func switchCell(switchCell: SwitchCell, didChangeValue value: Bool)
}

class SwitchCell: UITableViewCell {

    @IBOutlet weak var switchlabel: UILabel!
    
    @IBOutlet weak var onSwitch: UISwitch!
    
    weak var delegate: SwitchCellDelegate?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        onSwitch.onTintColor = UIColor(red: 207.0/255.0, green: 68.0/255.0, blue: 13.0/255.0, alpha: 1.0)
        onSwitch.addTarget(self, action: #selector(SwitchCell.switchValueChanged), for: UIControlEvents.valueChanged )
        
        //setting UITabBar appearance
        /*UINavigationBar.appearance().titleTextAttributes = [NSForegroundColorAttributeName : UIColor.gray]
        UITabBarItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.gray], for:.normal
        UITabBarItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor(red: 255.0/255.0, green: 90.0/255.0, blue: 11.0/255.0, alpha: 1.0)], for:.selected)*/
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    func switchValueChanged() {
        print("switch value changed")
        //similar to if statement
        delegate?.switchCell?(switchCell: self, didChangeValue: onSwitch.isOn)
    }
    
    

}
